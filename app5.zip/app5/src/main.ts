import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { NestExpressApplication } from '@nestjs/platform-express';
import path from 'path';
import { join } from 'path';
import * as ejs from 'ejs';
import * as express from 'express';


async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);
  app.use(express.static('public'));
app.set('view engine', 'ejs');

  app.engine('html', ejs.renderFile);
  app.set('view engine', 'html');
  app.set('views', join(__dirname, '..', 'views'));
  await app.listen(3000);
}
bootstrap();
